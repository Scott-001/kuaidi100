# python3.10

import requests


r = requests.request()